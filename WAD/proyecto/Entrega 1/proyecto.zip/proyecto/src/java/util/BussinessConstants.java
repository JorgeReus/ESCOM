/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Reus Gaming PC
 */
public class BussinessConstants {
    
    public static final int USER_TYPE_ADMINISTRATOR = 1;
    public static final int USER_TYPE_TEACHER = 2;
    public static final int USER_TYPE_STUDENT = 3;
    
}
